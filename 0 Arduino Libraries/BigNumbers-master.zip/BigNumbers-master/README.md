BigNumbers
==========

Library for displaying large numbers on LCD displays using the HD44780 driver.
