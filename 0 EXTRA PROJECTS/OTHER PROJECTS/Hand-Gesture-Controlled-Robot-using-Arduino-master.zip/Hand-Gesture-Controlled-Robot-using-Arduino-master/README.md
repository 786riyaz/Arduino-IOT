# Hand-Gesture-Controlled-Robot-using-Arduino
This github includes the complete circuit, code &amp; libraries of Hand Gesture Controlled Robot Project using RF Module, ADXL335 &amp; Arduino

If you want to learn more about the Project than you can watch these Videos:

Hand Gesture Controlled Robot Project Part 1: https://youtu.be/n5UGB0S4qHQ 

Hand Gesture Controlled Robot Project Part 2: https://youtu.be/DpT_wH_o0CM
